export default function LoginPage() {
  return <h1>Login Page</h1>;
}
