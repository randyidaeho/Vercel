import { Button } from "@/components/ui/button";

export default function MarketingPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-background">
      <section className="w-full py-20 md:py-32 lg:py-40 xl:py-48">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl/none bg-clip-text text-transparent bg-gradient-to-r from-[#FB7806] to-[#CA4410]">
                Dew Flow Planner
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                The ultimate content planning dashboard for PixelDew. Connect your Google Sheets and streamline your workflow.
              </p>
            </div>
            <div className="space-x-4">
              <Button size="lg">Get Started</Button>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
