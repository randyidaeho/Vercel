export default function WorkspacesPage() {
  return <h1>Workspaces Page</h1>;
}
