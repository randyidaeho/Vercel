export default function AppPage() {
  return <h1>App Page</h1>;
}
